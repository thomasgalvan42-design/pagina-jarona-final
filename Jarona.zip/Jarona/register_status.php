<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$error = $_SESSION['register_error'] ?? null;
$success = $_SESSION['register_success'] ?? null;
unset($_SESSION['register_error'], $_SESSION['register_success']);

echo json_encode([
    'error' => $error,
    'success' => $success
], JSON_UNESCAPED_UNICODE);
?>
