<?php
session_start();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$error = $_SESSION['login_error'] ?? null;
unset($_SESSION['login_error']);

echo json_encode([
    'error' => $error
], JSON_UNESCAPED_UNICODE);
?>
