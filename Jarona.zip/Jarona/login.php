<?php
session_start();
require_once 'db_connect.php';

function loginError($message) {
    $_SESSION['login_error'] = $message;
    header('Location: login.html');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.html');
    exit();
}

$inputUser = trim($_POST['username'] ?? '');
$inputPass = $_POST['password'] ?? '';

if ($inputUser === '' || $inputPass === '') {
    loginError('status_fill_fields');
}

try {
    // bind_result() is used instead of get_result(), so the login also works
    // on PHP installations where mysqlnd is not enabled.
    $stmt = $conn->prepare(
        'SELECT id, username, password FROM users WHERE username = ? LIMIT 1'
    );

    if (!$stmt) {
        throw new Exception('Could not prepare login query.');
    }

    $stmt->bind_param('s', $inputUser);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows !== 1) {
        $stmt->close();
        $conn->close();
        loginError('status_incorrect');
    }

    $stmt->bind_result($userId, $username, $passwordHash);
    $stmt->fetch();

    if (!password_verify($inputPass, $passwordHash)) {
        $stmt->close();
        $conn->close();
        loginError('status_incorrect');
    }

    session_regenerate_id(true);
    $_SESSION['user_id'] = $userId;
    $_SESSION['username'] = $username;

    // Optional: transparently upgrade an older/weaker hash after a successful login.
    if (password_needs_rehash($passwordHash, PASSWORD_DEFAULT)) {
        $newHash = password_hash($inputPass, PASSWORD_DEFAULT);
        $update = $conn->prepare('UPDATE users SET password = ? WHERE id = ?');
        if ($update) {
            $update->bind_param('si', $newHash, $userId);
            $update->execute();
            $update->close();
        }
    }

    $stmt->close();
    $conn->close();

    header('Location: welcome.php');
    exit();
} catch (Throwable $e) {
    if (isset($stmt) && $stmt instanceof mysqli_stmt) {
        @$stmt->close();
    }
    if (isset($conn) && $conn instanceof mysqli) {
        @$conn->close();
    }

    // Do not expose database details to the browser.
    error_log('Jarona login error: ' . $e->getMessage());
    loginError('status_internal');
}
?>
