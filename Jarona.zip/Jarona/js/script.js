document.addEventListener("DOMContentLoaded", async () => {
    if (window.translationsReady) await window.translationsReady;
    const feedback = document.getElementById("feedback");

    window.translateFeedback = function () {
        if (!feedback || !feedback.dataset.translationKey || !window.translations) return;
        feedback.textContent = translate(feedback.dataset.translationKey);
    };

    if (feedback) {
        const isLogin = !!document.querySelector('form[action="login.php"]');
        const isRegister = !!document.getElementById("registerForm");
        const statusFile = isLogin ? "login_status.php" : (isRegister ? "register_status.php" : null);

        if (statusFile) {
            try {
                const response = await fetch(statusFile, {
                    credentials: "same-origin",
                    cache: "no-store"
                });

                if (response.ok) {
                    const data = await response.json();
                    const key = data.error || data.success;
                    if (key) {
                        feedback.dataset.translationKey = key;
                        feedback.textContent = window.translate ? translate(key) : key;
                        feedback.className = data.error ? "error" : "success";
                    }
                }
            } catch (error) {
                // Keep the forms usable even if the status request fails.
            }
        }
    }

    const registerForm = document.getElementById("registerForm");
    if (registerForm) {
        const username = document.getElementById("username");
        const password = document.getElementById("password");

        function showError(key) {
            feedback.dataset.translationKey = key;
            feedback.textContent = window.translate ? translate(key) : key;
            feedback.className = "error";
        }

        registerForm.addEventListener("submit", (event) => {
            const user = username.value.trim();
            const pass = password.value;

            if (user.length < 3 || user.length > 20) {
                event.preventDefault(); showError("status_username_length"); return;
            }
            if (!/^[A-Za-z0-9_]+$/.test(user)) {
                event.preventDefault(); showError("status_username_chars"); return;
            }
            if (!/[a-zA-Z]/.test(user) || !/[0-9]/.test(user)) {
                event.preventDefault(); showError("status_username_alnum"); return;
            }
            if (pass.length < 8 || pass.length > 32) {
                event.preventDefault(); showError("status_password_length"); return;
            }
            if (!/[a-z]/.test(pass) || !/[A-Z]/.test(pass) || !/[0-9]/.test(pass) || !/[^A-Za-z0-9]/.test(pass)) {
                event.preventDefault(); showError("status_password_complexity");
            }
        });
    }
});
