let translations = {};
let currentLang = localStorage.getItem("language") || "en";

async function loadTranslations() {
    try {
        const response = await fetch("translations.json", { cache: "no-store" });
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        translations = await response.json();
        applyTranslations();
    } catch (error) {
        console.error("Failed to load translation file:", error);
    }
}

function translate(key, lang = currentLang, variables = {}) {
    let text = translations?.[lang]?.[key] ?? translations?.en?.[key] ?? key;
    for (const [name, value] of Object.entries(variables)) {
        text = text.replaceAll(`{${name}}`, value);
    }
    return text;
}

function applyTranslations() {
    if (!translations.en || !translations.es) return;

    document.documentElement.lang = currentLang;

    document.querySelectorAll("[data-i18n]").forEach(el => {
        const key = el.getAttribute("data-i18n");
        // Preserve the authenticated state when the language changes.
        if (el.id === "authButton" && el.classList.contains("logout-button")) {
            el.textContent = `${translate("logout", currentLang)}${window.loggedUsername ? ` (${window.loggedUsername})` : ""}`;
            return;
        }
        const variables = {};
        if (key === "welcome") {
            variables.username = el.dataset.username || window.loggedUsername || "";
        }
        el.textContent = translate(key, currentLang, variables);
    });

    document.querySelectorAll("[data-i18n-placeholder]").forEach(el => {
        el.placeholder = translate(el.getAttribute("data-i18n-placeholder"));
    });

    document.querySelectorAll("[data-i18n-alt]").forEach(el => {
        el.alt = translate(el.getAttribute("data-i18n-alt"));
    });

    document.querySelectorAll("[data-i18n-button]").forEach(btn => {
        btn.textContent = currentLang === "en" ? translate("toggle_es") : translate("toggle_en");
    });

    // Translate server-side status messages already loaded by script.js.
    if (window.translateFeedback) window.translateFeedback();
}

function toggleLanguage() {
    if (!translations.en || !translations.es) {
        alert("Translation data is still loading. Please try again in a moment.");
        return;
    }
    currentLang = currentLang === "en" ? "es" : "en";
    localStorage.setItem("language", currentLang);
    applyTranslations();
}

window.translationsReady = loadTranslations();

document.addEventListener("DOMContentLoaded", () => {
    const button = document.getElementById("lang-btn");
    if (button) button.addEventListener("click", toggleLanguage);
});
