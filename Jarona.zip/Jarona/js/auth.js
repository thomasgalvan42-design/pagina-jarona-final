document.addEventListener("DOMContentLoaded", async () => {
    if (window.translationsReady) await window.translationsReady;
    const button = document.getElementById("authButton");
    if (!button) return;

    try {
        const response = await fetch("auth_status.php", {
            credentials: "same-origin",
            cache: "no-store"
        });
        if (!response.ok) throw new Error("Unable to check the session.");

        const data = await response.json();
        window.loggedUsername = data.username || "";

        if (data.loggedIn) {
            button.textContent = `${translate("logout")} (${data.username})`;
            button.href = "logout.php";
            button.classList.add("logout-button");
        } else {
            button.textContent = translate("login_register");
            button.href = "login.html";
        }
    } catch (error) {
        button.textContent = translate("login_register");
        button.href = "login.html";
    }

    if (typeof window.applyTranslations === "function") window.applyTranslations();

    const oldApply = window.applyTranslations;
    window.applyTranslations = function() {
        if (typeof oldApply === "function") oldApply();
        if (button.classList.contains("logout-button")) {
            button.textContent = `${translate("logout")} (${window.loggedUsername || ""})`;
        } else {
            button.textContent = translate("login_register");
        }
    };
});
