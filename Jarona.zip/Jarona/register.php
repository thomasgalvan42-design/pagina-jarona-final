<?php
session_start();
require_once 'db_connect.php';

function registerError($message) {
    $_SESSION['register_error'] = $message;
    header("Location: register.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: register.html");
    exit();
}

$user = trim($_POST['username'] ?? '');
$pass = $_POST['password'] ?? '';

if (strlen($user) < 3 || strlen($user) > 20) {
    registerError("status_username_length");
}

if (!preg_match('/^[A-Za-z0-9_]+$/', $user)) {
    registerError("status_username_chars");
}

$hasLetter = preg_match('/[a-zA-Z]/', $user);
$hasNumber = preg_match('/[0-9]/', $user);
if (!$hasLetter || !$hasNumber) {
    registerError("status_username_alnum");
}

// Reject an existing username before attempting the insert. The database
// collation is case-insensitive, so names such as User123 and user123 match.
$check = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
if (!$check) {
    registerError("status_prepare");
}
$check->bind_param("s", $user);
if (!$check->execute()) {
    $check->close();
    registerError("status_register_fail");
}
$check->store_result();
$usernameExists = $check->num_rows > 0;
$check->close();

if ($usernameExists) {
    $conn->close();
    registerError("status_duplicate");
}

if (strlen($pass) < 8 || strlen($pass) > 32) {
    registerError("status_password_length");
}

$hasLower = preg_match('/[a-z]/', $pass);
$hasUpper = preg_match('/[A-Z]/', $pass);
$hasDigit = preg_match('/[0-9]/', $pass);
$hasSpecial = preg_match('/[^A-Za-z0-9]/', $pass);
if (!$hasLower || !$hasUpper || !$hasDigit || !$hasSpecial) {
    registerError("status_password_complexity");
}

$hashedPassword = password_hash($pass, PASSWORD_DEFAULT);
$stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");

if (!$stmt) {
    registerError("status_prepare");
}

$stmt->bind_param("ss", $user, $hashedPassword);

try {
    $stmt->execute();
    $stmt->close();
    $conn->close();
    $_SESSION['register_success'] = "status_success";
    header("Location: login.html");
    exit();
} catch (mysqli_sql_exception $e) {
    $message = ($e->getCode() === 1062)
        ? "status_duplicate"
        : "status_register_fail";
    $stmt->close();
    $conn->close();
    registerError($message);
}
?>
