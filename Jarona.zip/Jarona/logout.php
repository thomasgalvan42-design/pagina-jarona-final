<?php
session_start();

// Vaciar los datos de la sesión actual.
$_SESSION = [];

// Eliminar también la cookie de sesión si PHP la está utilizando.
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

session_destroy();

// Después de cerrar sesión, volvemos a la página principal.
header("Location: mantenimiento.html");
exit();
?>
