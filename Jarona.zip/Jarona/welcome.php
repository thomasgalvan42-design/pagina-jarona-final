<?php
session_start();

// Si no hay una sesión iniciada, volvemos al login.
if (!isset($_SESSION['username'])) {
    $_SESSION['login_error'] = "status_login_first";
    header("Location: login.html");
    exit();
}

$username = htmlspecialchars($_SESSION['username'], ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="3;url=mantenimiento.html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title data-i18n="welcome">Welcome</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/auth.css">
    <link rel="stylesheet" href="css/translations.css">
</head>
<body>
    <div class="welcome">
        <span data-i18n="welcome" data-username="<?php echo $username; ?>">
            ¡Bienvenido, <?php echo $username; ?>!
        </span>
        <p class="redirect-message">
            <span data-i18n="t_redirigiendo_a">Redirigiendo a</span>
            <a href="mantenimiento.html" data-i18n="t_inicio">Inicio</a>...
        </p>
    </div>

    <div class="logout">
        <a id="authButton" class="auth-button logout-button" href="logout.php" data-i18n="logout">Logout</a>
    </div>

    <button id="lang-btn" type="button" class="language-button" data-i18n-button="true">
        Switch to Español
    </button>

    <script src="js/translations.js"></script>
    <script src="js/auth.js"></script>
    <script>
        // Redirección principal mediante JavaScript; el meta refresh del head
        // queda como respaldo si JavaScript no está disponible.
        setTimeout(() => {
            window.location.href = "mantenimiento.html";
        }, 3000);
    </script>
</body>
</html>
