# Jarona

## Estructura
- `*.html`: páginas del sitio.
- `css/`: hojas de estilo.
- `js/`: lógica del navegador y traducciones.
- `*.php`: autenticación, sesiones y conexión a la base de datos.
- `sql/setup.sql`: creación de la base de datos y tabla de usuarios.
- `img/`: imágenes y recursos gráficos.
- `docs/`: documentación del proyecto.
- `translations.json`: textos en inglés y español.

## Cambios aplicados
- Quitado el botón de llamada a servicios de la página principal.
- Corregido el estado del botón de autenticación para que conserve “Logout / Cerrar sesión” al cambiar el idioma.
- Ajustado el selector de idioma para que no quede recortado en pantallas pequeñas.
- Añadida una sección de contacto ficticia en About.

## Nota importante
El correo y el teléfono de About son datos de ejemplo. Sustitúyelos por los datos reales antes de publicar el sitio.
